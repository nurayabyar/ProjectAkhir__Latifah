<h1> Selamat Datang dihalaman, Dashboard<h1>
<?= $this->session->userdata('nama'); ?>