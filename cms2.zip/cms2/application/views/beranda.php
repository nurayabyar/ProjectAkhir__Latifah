<!DOCTYPE html>
<html lang="en">

<head>
	<title>BookSaw - Free Book Store HTML CSS Template</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="format-detection" content="telephone=no">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="author" content="">
	<meta name="keywords" content="">
	<meta name="description" content="">

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
 
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/frontend/'); ?>css/normalize.css">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/frontend/'); ?>icomoon/icomoon.css">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/frontend/'); ?>css/vendor.css">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/frontend/'); ?>style.css">

</head>

<body data-bs-spy="scroll" data-bs-target="#header" tabindex="0">

	<div id="header-wrap">

		<div class="top-content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-6">
						<div class="social-links">
							<!-- <ul>
								<li>
									<a href="#"><i class="icon icon-facebook"></i></a>
								</li>
								<li>
									<a href="#"><i class="icon icon-twitter"></i></a>
								</li>
								<li>
									<a href="#"><i class="icon icon-youtube-play"></i></a>
								</li>
								<li>
									<a href="#"><i class="icon icon-behance-square"></i></a>
								</li>
							</ul> -->
						</div><!--social-links-->
					</div>
					<div class="col-md-6">
						<div class="right-element">
							<a href="<?= base_url('auth') ?>" class="user-account for-buy"><i
									class="icon icon-user"></i><span>Account</span></a>

							<div class="action-menu">

								<div class="search-bar">
									<a href="#" class="search-button search-toggle" data-selector="#header-wrap">
										<i class="icon icon-search"></i>
									</a>
									<form role="search" method="get" class="search-box" action="<?= base_url('home/search') ?>">
										<input class="search-field text search-input" placeholder="Search" 
											type="search" name="keyword">
									</form>
									
								</div>
							</div>

						</div><!--top-right-->
					</div>

				</div>
			</div>
		</div><!--top-content-->

		<header id="header">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-2">
						<div class="main-logo">
							<h2 class="banner-title"><?= $konfig->judul_website; ?></h2>
						</div>
					</div>

					<div class="col-md-10">

						<nav id="navbar">
							<div class="main-menu stellarnav">
								<ul class="menu-list">
									<li class="menu-item active"><a href="#home">Home</a></li>
									<li class="menu-item"><a href="#popular-books" class="nav-link">Popular</a></li>
								</ul>

								<div class="hamburger">
									<span class="bar"></span>
									<span class="bar"></span>
									<span class="bar"></span>
								</div>

							</div>
						</nav>

					</div>
				</div>
			</div>
		</header>

	</div><!--header-wrap-->

	<section id="billboard">

		<div class="container">
			<div class="row">
				<div class="col-md-12">

					<button class="prev slick-arrow">
						<i class="icon icon-arrow-left"></i>
					</button>

					<div class="main-slider pattern-overlay">
						<div class="slider-item">
							<div class="banner-content">
								<h2 class="banner-title">Antalogi Rasa</h2>
								<p>cerita tentang cinta segitiga yang rumit diantara tiga sahabat yaitu keara, ruly, dan haris</p>

							</div><!--banner-content-->
              				<div class="hero_area">
              				<div class="bg-box">
              				<div class="d-flex flex-column  justify-content-center">
              				<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
              				<div class="carousel-inner">
              				<?php $no=1; foreach ($caraousel as $aa){ ?>
                			<div class="carousel-item <?php if($no==1) {echo 'active';} ?>">
							<img src="<?= base_url('assets/upload/caraousel/'.$aa['foto']) ?>" alt="banner" class="banner-image">
              				<?php $no++; } ?>
						</div><!--slider-item-->
					</div><!--slider-->

					</div><!--image-holder-->
				</div>
			</div>
		</div>
	</section>

	

	<section id="popular-books" class="bookshelf py-5 my-5">
		<div class="container">
			<div class="row">
				<div class="col-md-12">

					<div class="section-header align-center">
						<div class="title">
							<span>Some quality items</span>
						</div>
						<h2 class="section-title">Popular Books</h2>
					</div>

					<ul class="tabs">
						<?php foreach($kategori as $kate){ ?>
						<li data-tab-target="#business" class="tab"><a href="<?= base_url('home/kategori/').$kate['id_kategori'] ?>"><?= $kate['nama_kategori'] ?></a></li>
						<?php } ?>
					</ul>

<div class="tab-content">
		<div id="all-genre" data-tab-content class="active">
			<div class="row">
			<?php  foreach ($konten as $uu){ ?>
				<div class="col-md-3">
					<div class="product-item">
						<figure class="product-style">
							<img src="<?= base_url('assets/upload/konten/'.$uu['foto']) ?>" alt="Books" class="product-item">
						</figure>
						<figcaption>
							<h3><?= $uu['judul'] ?></h3>
							<span><?= $uu['nama_kategori'] ?></span>
							<div class="btn-wrap">
							<a href="<?= base_url('home/artikel/'.$uu['slug']) ?>" class="btn btn-outline-accent btn-accent-arrow">Read More<i
							class="icon icon-ns-arrow-right"></i></a>
							</div>
						</figcaption>
					</div>
                </div>
				<?php } ?>
                
               
		</div>
	</div>
</section>

	
	<footer id="footer">
	<section id="subscribe">
		<div class="container">
			<div class="row">

				<div class="col-md-4">

					<div class="footer-item">
						<div class="company-brand">
						<h2 class="banner-title"><?= $konfig->judul_website; ?></h2>
						<p><?= $konfig->profil_website; ?></p>
						<div class="d-flex justify-content-start mt-4">
						<div class="social-links align-right">
							<!-- <ul>
								<li>
									<a href="<?= $konfig->facebook; ?>"><i class="icon icon-facebook"></i></a>
								</li>
								<li>
									<a href="<?= $konfig->instagram; ?>"><i class="icon icon-instagram"></i></a>
								</li>
								</ul> -->
								</div>
         					</div>
						</div>
					</div>

				</div>

				<div class="col-md-2"></div>
				<div class="col-md-2"></div>

				<div class="col-md-2">

					<div class="footer-menu">
						<h5>Quick Links</h5>
						<ul class="menu-list">
							<li class="menu-item">
								<a href="<?= base_url() ?>">Home</a>
								<?php foreach ($kategori as $kate){ ?>
            					</a>
            					<a class="text-black mb-2" href="<?= base_url('home/kategori/'.$kate['id_kategori']) ?>">
                				<i class="fa fa-angle-right mr-2"></i><?= $kate['nama_kategori'] ?>
            					</a>
            				<?php } ?>
							</li>
						</ul>
					</div>
				</div>

				<div class="col-md-2"></div>

			</div>
			<!-- / row -->

		</div>
		</section>
	</footer>

	<div id="footer-bottom">
		<div class="container">
			<div class="row">
				<div class="col-md-12">

					<div class="copyright">
						<div class="row">

							<div class="col-md-6">
								<p>© 2022 All rights reserved. Free HTML Template by <a
										href="https://www.templatesjungle.com/" target="_blank">TemplatesJungle</a></p>
							</div>

							<div class="col-md-6">
								<div class="social-links align-right">
									<!-- <ul>
										<li>
											<a href="#"><i class="icon icon-facebook"></i></a>
										</li>
										<li>
											<a href="#"><i class="icon icon-twitter"></i></a>
										</li>
										<li>
											<a href="#"><i class="icon icon-youtube-play"></i></a>
										</li>
										<li>
											<a href="#"><i class="icon icon-behance-square"></i></a>
										</li>
									</ul> -->
								</div>
							</div>

						</div>
					</div><!--grid-->

				</div><!--footer-bottom-content-->
			</div>
		</div>
	</div>

	<script src="<?= base_url('assets/frontend/'); ?>js/jquery-1.11.0.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
		crossorigin="anonymous"></script>
	<script src="<?= base_url('assets/frontend/'); ?>js/plugins.js"></script>
	<script src="<?= base_url('assets/frontend/'); ?>js/script.js"></script>

</body>

</html>