<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Konten extends CI_Controller {
    public function __construct(){
        parent::__construct();
        if ($this->session->userdata('level')==NULL){
            redirect('auth');
        }
    }
	public function index(){
        $this->db->from('kategori');
        $this->db->order_by('nama_kategori', 'ASC');
        $kategori = $this->db->get()->result_array();

        $this->db->from('konten a');
        $this->db->join('kategori b', 'a.id_kategori=b.id_kategori', 'left');
        $this->db->join('user c', 'a.username=c.username', 'left');
        $this->db->order_by('tanggal', 'DESC');
        $konten = $this->db->get()->result_array();
		$data = array(
			'judul_halaman' => 'Halaman konten',
            'kategori'      => $kategori,
            'konten'        => $konten
		);
		$this->template->load('template_admin', 'admin/konten_index',$data);
	}
    public function simpan(){
        $namafoto = date('YmdHis').'.jpg';
        $config['upload_path']          = 'assets/upload/konten/';
        $config['max_size'] = 500 * 1024; //3 * 1024 * 1024; //3Mb; 0=unlimited
        $config['file_name']            = $namafoto;
        $config['allowed_types']        = '*';
        $this->load->library('upload', $config);
        if($_FILES['foto']['size'] >= 500 * 1024){
            $this->session->set_flashdata('alert', '
                <div class="alert alert-danger alert-dismissible" role="alert">
                Ukuran foto terlalu besar, upload ulang foto dengn ukuran yang kurang dari 500 KB.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                    ');
            redirect('admin/konten');
    }   elseif( ! $this->upload->do_upload('foto')){
            $error = array('error' => $this->upload->display_errors());
    }else{
        $data = array('upload_data' => $this->upload->data());
    }



        $this->db->from('konten');
        $this->db->where('judul', $this->input->post('judul'));
        $cek = $this->db->get()->result_array();
        if($cek<>NULL){
            $this->session->set_flashdata('alert', '
            <div class="alert alert-dark alert-dismissible mb-0" role="alert">
                Judul Konten sudah ada.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            ');
            redirect('admin/konten');
        }
        
        $data = array(
            'judul'             =>  $this->input->post('judul'),
            'id_kategori'       =>  $this->input->post('id_kategori'),
            'keterangan'        =>  $this->input->post('keterangan'),
            'tanggal'           =>  date('Y-m-d'),
            'foto'              =>  $namafoto,
            'username'          =>  $this->session->userdata('username'),
            'slug'              =>  str_replace(' ', '-', $this->input->post('judul'))
        );

        $this->db->insert('konten',$data);
        $this->session->set_flashdata('alert', '
        <div class="alert alert-dark alert-dismissible mb-0" role="alert">
            Berhasil menabahkan kategori.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        ');
        redirect('admin/konten');
    }
    
    public function update() {
        // Ambil data input dari form
        $judul = $this->input->post('judul');
        $id_kategori = $this->input->post('id_kategori');
        $keterangan = $this->input->post('keterangan');
        $namafoto = $this->input->post('namafoto'); // Nama foto lama untuk mengganti jika foto tidak diubah
        $id_konten = $this->input->post('id_konten'); // ID konten untuk pencarian data yang akan diupdate
    
        // Debugging: Lihat data input dari form
        var_dump($this->input->post()); // Memeriksa seluruh data yang dikirim
    
        // Validasi input
        if (empty($judul) || empty($id_kategori) || empty($keterangan) || empty($id_konten)) {
            $this->session->set_flashdata('alert', '
                <div class="alert alert-danger alert-dismissible mb-0" role="alert">
                    Semua kolom wajib diisi!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            ');
            redirect('admin/konten');
            return;
        }
    
        // Siapkan array data untuk update
        $data = array(
            'judul'       => $judul,
            'id_kategori' => $id_kategori,
            'keterangan'  => $keterangan,
            'slug'        => url_title($judul, '-', true) // Membuat slug dari judul
        );
    
        // Jika ada file foto baru yang diupload
        if (!empty($_FILES['foto']['name'])) {
            // Setup konfigurasi upload file
            $config['upload_path'] = 'assets/upload/konten/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name'] = $namafoto;
            $config['overwrite'] = true;
            $config['max_size'] = 500 * 1024; // Maksimum ukuran file 500 KB
    
            $this->load->library('upload', $config);
    
            // Jika file gagal diupload
            if (!$this->upload->do_upload('foto')) {
                $this->session->set_flashdata('alert', '
                    <div class="alert alert-danger alert-dismissible mb-0" role="alert">
                        Error saat mengunggah file: ' . $this->upload->display_errors() . '
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                ');
                redirect('admin/konten');
                return;
            }
    
            // Jika upload sukses, simpan nama file yang baru
            $upload_data = $this->upload->data();
            $data['foto'] = $upload_data['file_name'];
        }
    
        // Jika foto tidak diubah, tetap gunakan foto lama
        if (empty($_FILES['foto']['name'])) {
            $data['foto'] = $namafoto;
        }
    
        // Update data berdasarkan ID konten yang dikirim
        $where = array('id_konten' => $id_konten); // Filter berdasarkan ID konten
        $update = $this->db->update('konten', $data, $where); // Lakukan update
    
        // Jika update sukses
        if ($update) {
            $this->session->set_flashdata('alert', '
                <div class="alert alert-dark alert-dismissible mb-0" role="alert">
                    Berhasil memperbarui konten.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            ');
        } else {
            $this->session->set_flashdata('alert', '
                <div class="alert alert-danger alert-dismissible mb-0" role="alert">
                    Gagal memperbarui konten. Silakan coba lagi.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            ');
        }
    
        redirect('admin/konten');
    }
    
    
    
}